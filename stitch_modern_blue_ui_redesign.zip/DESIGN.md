---
name: Monolith Enterprise
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#424656'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#727687'
  outline-variant: '#c2c6d8'
  surface-tint: '#0054d6'
  primary: '#0050cb'
  on-primary: '#ffffff'
  primary-container: '#0066ff'
  on-primary-container: '#f8f7ff'
  inverse-primary: '#b3c5ff'
  secondary: '#5e5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e2e2e2'
  on-secondary-container: '#646464'
  tertiary: '#a33200'
  on-tertiary: '#ffffff'
  tertiary-container: '#cc4204'
  on-tertiary-container: '#fff6f4'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae1ff'
  primary-fixed-dim: '#b3c5ff'
  on-primary-fixed: '#001849'
  on-primary-fixed-variant: '#003fa4'
  secondary-fixed: '#e2e2e2'
  secondary-fixed-dim: '#c6c6c6'
  on-secondary-fixed: '#1b1b1b'
  on-secondary-fixed-variant: '#474747'
  tertiary-fixed: '#ffdbd0'
  tertiary-fixed-dim: '#ffb59d'
  on-tertiary-fixed: '#390c00'
  on-tertiary-fixed-variant: '#832600'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display:
    fontFamily: Geist
    fontSize: 48px
    fontWeight: '600'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '500'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: '0'
  body-md:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: '0'
  body-sm:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: '0'
  label-md:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
  code:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: '0'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  container-max: 1440px
  sidebar-width: 260px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style

This design system is engineered for high-stakes Contract Lifecycle Management, where clarity, authority, and precision are paramount. The brand personality is "Quiet Confidence"—a stoic, hyper-professional aesthetic that recedes into the background to let complex legal data take center stage.

The style is **High-Fidelity Minimalism**. It leverages a "Software-as-Infrastructure" approach, utilizing extreme whitespace, rigorous alignment, and a restricted color palette to reduce cognitive load. While the foundation is monochromatic and architectural, the strategic use of a singular vibrant blue ensures that "intent" is never ambiguous. The emotional response should be one of total control, security, and institutional trust.

## Colors

The palette is strictly functional. Pure **White (#FFFFFF)** serves as the primary canvas to maximize perceived space, while **Black (#000000)** is reserved for high-contrast typography and primary navigation elements.

- **Primary Blue (#0066FF):** Used exclusively for "Action" and "Focus." This includes primary buttons, active states, progress indicators, and links.
- **Neutrals:** A scale of cool grays is used for secondary information, borders, and subtle surface fills to distinguish between the background and container elements.
- **Semantic Accents:** Success (Emerald), Warning (Amber), and Error (Crimson) are used sparingly and at low saturation for status badges to prevent the UI from feeling "loud."

## Typography

The design system utilizes **Geist** for its technical precision and optimal legibility in data-dense environments. The typographic hierarchy is strictly enforced:

- **Headlines:** Use tighter letter-spacing and heavier weights for immediate identification of views.
- **Body:** Generous line-height (1.5x - 1.6x) is mandatory for long-form legal text and contract previews to ensure readability.
- **Labels:** Small caps or uppercase with increased tracking are used for metadata, table headers, and overlines to distinguish them from actionable data.
- **Numerical Data:** For metric cards and tables, tabular figures should be enabled to ensure vertical alignment of digits.

## Layout & Spacing

The layout follows a **Fixed-Fluid Hybrid** model. The sidebar remains fixed at 260px, while the main content area occupies the remaining width up to a 1440px maximum to prevent line-lengths from becoming unreadable on ultra-wide monitors.

A 4px baseline grid governs all spacing. 
- **Grids:** A 12-column system is used for dashboard layouts. Metric cards typically span 3 columns, while data tables span 12.
- **Responsive Behavior:** On tablet, the sidebar collapses into a narrow icon-only rail (72px). On mobile, the sidebar moves to a bottom-sheet or top-drawer, and margins reduce to 16px.
- **Padding:** High density is avoided. Generous internal padding within cards (min 24px) creates an "Executive" feel.

## Elevation & Depth

This design system uses a **Tonal Layering** approach supplemented by **Micro-Shadows**. 

- **Level 0 (Background):** Pure White (#FFFFFF).
- **Level 1 (Cards/Sidebar):** Surface-colored (#F8FAFC) or White with a 1px border (#E2E8F0).
- **Shadows:** Avoid heavy, dark shadows. Use a single "Ambient" shadow for elevated elements: `0px 1px 2px rgba(0, 0, 0, 0.05), 0px 4px 12px rgba(0, 0, 0, 0.03)`. 
- **Depth Cues:** Depth is primarily indicated by borders rather than shadows. In a dashboard view, use subtle gray borders to define the "territory" of different data modules.

## Shapes

The shape language is **Soft (0.25rem)**. This provides a modern, refined touch without appearing overly "bubbly" or consumer-grade.

- **Base Radius:** 4px (0.25rem) for input fields, small buttons, and checkboxes.
- **Container Radius:** 8px (0.5rem) for dashboard cards and modal windows.
- **Selection States:** Use subtle rounded rectangles for hover states in lists and navigation items.

## Components

### Buttons
- **Primary:** Solid Black or Primary Blue with White text. No gradients. 
- **Secondary:** White fill with a 1px Gray-300 border. 
- **Ghost:** No fill or border; text only. Used for secondary actions in tables.

### Data Tables
- **Headers:** Sticky, Gray-50 background, uppercase 12px labels. 
- **Rows:** Minimum height 56px. Subtle border-bottom only. No alternating zebra stripes; use hover-highlighting instead.
- **Cells:** Vertical alignment centered. Status indicators use a small dot (8px) + text.

### Metric Cards
- Large "Display" sized numbers.
- Trend indicators (up/down arrows) placed next to the value.
- Subtle 1px border; no shadow unless hovered.

### Sidebar Navigation
- Dark mode optional for sidebar only to create separation.
- High-contrast active states using a vertical 4px bar on the left edge in Primary Blue.

### Input Fields
- Understated design: 1px border (#E2E8F0) that turns Primary Blue on focus.
- Floating labels or persistent top-aligned labels in `label-md` style.